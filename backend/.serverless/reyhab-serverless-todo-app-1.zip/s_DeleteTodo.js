
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'reyhab',
  applicationName: 'reypitson',
  appUid: '0hTPSdqqCCW4zGrsDG',
  orgUid: 'feae44ca-25e2-469b-8fb0-6b6a5a54f578',
  deploymentUid: 'c0a474d2-1245-4688-a694-42d38c1c1d90',
  serviceName: 'reyhab-serverless-todo-app-1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'reyhab-serverless-todo-app-1-dev-DeleteTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deleteTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}